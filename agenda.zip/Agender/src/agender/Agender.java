package agender;
import View.SplashScreen_GUI;

public class Agender {

    public static void main(String[] args) {
        new SplashScreen_GUI().setVisible(true);
    }
    
}
