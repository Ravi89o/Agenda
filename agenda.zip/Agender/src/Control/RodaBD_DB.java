package Control;
public class RodaBD_DB {
    public static  void carregaDriver(){
       try { // Conecttando o driver
            Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
            System.out.println("Driver carregado com sucesso!");




       } catch (Exception ex) { // Erro driver não encontrado
            System.out.println("Driver nao pode ser carregado!");
        }

    }
}
