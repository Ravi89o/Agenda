package Model;

import View.Agenda_GUI;
import java.util.Calendar;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import static View.Agenda_GUI.dataAlterada_txt;
import static View.Agenda_GUI.motivoAlterado_txt;
import static View.Agenda_GUI.buscar_txt;
import static View.Agenda_GUI.codigo_txt;
import static View.Agenda_GUI.data_dc;
import static View.Agenda_GUI.datasExibidas_tb;
import static View.Agenda_GUI.motivo_txt;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.PreparedStatement;

public class Engine_DAO {
    public static String url = "jdbc:mysql://localhost:3306/agenda";
    public static String username = "root";
    public static String password = "root";
    
    public static void Verificar_Data() {
    try {
        Calendar calendar = Calendar.getInstance();
        int dia = calendar.get(Calendar.DAY_OF_MONTH);
        int mes = calendar.get(Calendar.MONTH) + 1;
        int ano = calendar.get(Calendar.YEAR);

        Connection con = DriverManager.getConnection(url, username, password);

        String sql = "SELECT dado_cod, dado_time, dado_moti FROM dados;";
        String sql2 = "SELECT COUNT(*) FROM dados;";
        PreparedStatement stm = con.prepareStatement(sql);
        PreparedStatement stm2 = con.prepareStatement(sql2);
        
        ResultSet resultSet = stm.executeQuery();
        ResultSet resultSet2 = stm2.executeQuery();

        if (resultSet2.next()) {
            while (resultSet.next()) {
            String data = resultSet.getString("dado_time");
            String motivo = resultSet.getString("dado_moti");
            int anoFuturo = Integer.parseInt(data.substring(0, 4));
            int mesFuturo = Integer.parseInt(data.substring(5, 7));
            int diaFuturo = Integer.parseInt(data.substring(8, 10));
            if((diaFuturo == dia+1) && (mesFuturo == mes) && (anoFuturo == ano)){
                JOptionPane.showMessageDialog(null, "Tarefa à fazer para amanhã: "+motivo);
            }
            
            
        }
        } else {
            JOptionPane.showMessageDialog(null, "Nenhum dado encontrado.");
        }

        resultSet.close();
        stm.close();
        con.close();

    } catch (SQLException ex) {
        JOptionPane.showMessageDialog(null, "Erro ao acessar o banco de dados!", "ERRO", JOptionPane.ERROR_MESSAGE);
    }
    }
    
    public static void salvar_Data(){
        String motivo = motivo_txt.getText();
        Date time = data_dc.getDate();
        if(motivo_txt.getText().isEmpty() || time == null){
        JOptionPane.showMessageDialog(null, "Insira um motivo e/ou uma data");
        } else{
        Control.RodaBD_DB.carregaDriver();
        
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(time);
        int dia = calendar.get(Calendar.DAY_OF_MONTH);
        int mes = calendar.get(Calendar.MONTH) + 1;
        int ano = calendar.get(Calendar.YEAR);
        String tempo = ano+"-"+mes+"-"+dia;
        
        try { 
            Connection con = null; 
            
            try {
                con = (Connection) DriverManager.getConnection(url, username, password);
            } catch (SQLException ex) {
            Logger.getLogger(Agenda_GUI.class.getName()).log(Level.SEVERE, null, ex);
                   }
            // Recebendo os dados a serem inseridos na tabela
            String sql = "INSERT INTO dados(dado_time,dado_moti) values('"+tempo+"','"+motivo+"')";
            try { // Tratamento de Erros para inserção
                // Criando varialvel que executara a inserção
                PreparedStatement inserir = con.prepareStatement(sql);
                inserir.execute(); // Executando a inserção
                JOptionPane.showMessageDialog(null,"\nInserção realizada com sucesso!!!\n","",-1);
                motivo_txt.setText("");
                data_dc.setDate(null);
                Model.Engine_DAO.Apagar_Tabela();
                Model.Engine_DAO.Atualizar_Tabela();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(null,"\nErro na inserção!","ERRO!",0);
            }
        }catch(NumberFormatException erro){
            // Tratamento de erro caso o usuario não digite o telefone corretamente
            JOptionPane.showMessageDialog(null,"Digite os dados corretamente","ERRO",0);
        }
        }
        
    }
    
    public static void Buscar() {
    try {
        int codigo = Integer.parseInt(buscar_txt.getText());
        Control.RodaBD_DB.carregaDriver();
        try (Connection con = DriverManager.getConnection(url, username, password)) {
            String sql = "SELECT dado_time, dado_moti FROM dados WHERE dado_cod = ?";
            try (PreparedStatement stm = con.prepareStatement(sql)) {
                stm.setInt(1, codigo);
                try (ResultSet rs = stm.executeQuery()) {
                    int i = 0;
                    while (rs.next()) {
                        String moti = rs.getString("dado_moti");
                        String time = rs.getString("dado_time");
                        i++;
                        motivoAlterado_txt.setText(moti);
                        dataAlterada_txt.setText(time);
                    }
                    if (i == 0) {
                        JOptionPane.showMessageDialog(null, "Dado não cadastrado", "Resultado", JOptionPane.INFORMATION_MESSAGE);
                    }
                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(null, "Erro ao consultar!", "ERRO", JOptionPane.ERROR_MESSAGE);
                }
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao conectar com o servidor", "ERRO!", JOptionPane.ERROR_MESSAGE);
        }
    } catch (NumberFormatException erro) {
        JOptionPane.showMessageDialog(null, "Digite o código corretamente", "ERRO", JOptionPane.ERROR_MESSAGE);
        dataAlterada_txt.setText("");
    }
}
    
    public static void Salvar_Ateracao(){
      String motivoAlterado = motivoAlterado_txt.getText(); // recebendo o nome
      String dataAlterada = dataAlterada_txt.getText();

       Control.RodaBD_DB.carregaDriver();
       
      try {     
            Connection con = null;
      try {
            con = (Connection) DriverManager.getConnection(url, username, password);
      }catch (SQLException ex) {
            Logger.getLogger(View.Agenda_GUI.class.getName()).log(Level.SEVERE, null, ex);
      }
            String sql = "UPDATE dados SET dado_time='"+dataAlterada+"',dado_moti='"+motivoAlterado+"' WHERE dado_cod="+buscar_txt.getText();
            
     
            try { 
                PreparedStatement inserir = (PreparedStatement) con.prepareStatement(sql);
                inserir.execute();

                JOptionPane.showMessageDialog(null,"\nInserção realizada com sucesso!!!\n","",-1);
                motivoAlterado_txt.setText("");
                dataAlterada_txt.setText("");
                buscar_txt.setText("");
                Model.Engine_DAO.Apagar_Tabela();
                Model.Engine_DAO.Atualizar_Tabela();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(null,"\nErro na inserção!","ERRO!",0);
            }

        }catch(NumberFormatException erro){
            JOptionPane.showMessageDialog(null,"Digite os dados corretamente","ERRO",0);
            dataAlterada_txt.setText("");
        }    
    }
    
    public static void Excluir_Data(){
      String codigo = codigo_txt.getText();

       Control.RodaBD_DB.carregaDriver();
       
      try {     
            Connection con = null;
      try {
            con = (Connection) DriverManager.getConnection(url, username, password);
      }catch (SQLException ex) {
            Logger.getLogger(View.Agenda_GUI.class.getName()).log(Level.SEVERE, null, ex);
      }
            String sql = "DELETE FROM dados WHERE dado_cod = "+codigo+";";
            
     
            try { 
                PreparedStatement excluir = (PreparedStatement) con.prepareStatement(sql);
                excluir.execute();

                JOptionPane.showMessageDialog(null,"\nInserção realizada com sucesso!!!\n","",-1);
                codigo_txt.setText("");
                Model.Engine_DAO.Apagar_Tabela();
                Model.Engine_DAO.Atualizar_Tabela();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(null,"\nErro na inserção!","ERRO!",0);
            }

        }catch(NumberFormatException erro){
            JOptionPane.showMessageDialog(null,"Digite os dados corretamente","ERRO",0);
            codigo_txt.setText("");
        }    
           
        }
            
    public static void Atualizar_Tabela(){
        try {
            Control.RodaBD_DB.carregaDriver();
            Connection con = null;
            con = (Connection) DriverManager.getConnection(url, username, password);
            String sql = "SELECT dado_cod, dado_time, dado_moti FROM dados";
            PreparedStatement stm = (PreparedStatement) con.prepareStatement(sql);
            ResultSet resultSet = stm.executeQuery();   
            
            while (resultSet.next()) {
                String cod = resultSet.getString("dado_cod");
                String data = resultSet.getString("dado_time");
                String motivo = resultSet.getString("dado_moti");
                DefaultTableModel tbprodutos = (DefaultTableModel) datasExibidas_tb.getModel();
                
                Object[] dados = {cod, data, motivo};
                
                tbprodutos.addRow(dados);
            }
        } catch (SQLException ex) {
            Logger.getLogger(Agenda_GUI.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    
    }
    
    public static void Apagar_Tabela(){
    DefaultTableModel tbprodutos = (DefaultTableModel) datasExibidas_tb.getModel();
    tbprodutos.setRowCount(0);
    }
    }
